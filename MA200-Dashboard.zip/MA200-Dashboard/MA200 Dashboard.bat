@echo off
setlocal
cd /d "%~dp0"

set "URL=http://127.0.0.1:8000/"
set "PYTHON="
if exist ".venv\Scripts\pythonw.exe" set "PYTHON=.venv\Scripts\pythonw.exe"
if not defined PYTHON if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"
if not defined PYTHON set "PYTHON=pythonw"

powershell -NoProfile -Command "try { $r = Invoke-WebRequest -Uri '%URL%' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
if %ERRORLEVEL%==0 (
    start "" "%URL%"
    exit /b 0
)

start "" /B "%PYTHON%" app.py >nul 2>&1

set /a tries=0
:wait_loop
powershell -NoProfile -Command "try { $r = Invoke-WebRequest -Uri '%URL%' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
if %ERRORLEVEL%==0 goto open_browser
set /a tries+=1
if %tries% geq 15 goto open_browser
timeout /t 1 /nobreak >nul
goto wait_loop

:open_browser
start "" "%URL%"

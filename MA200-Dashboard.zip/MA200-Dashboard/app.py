from __future__ import annotations

import asyncio
import os
from collections import deque
from typing import Dict, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from serial_reader import SerialConfig, list_com_ports, pump_serial_to_queue
from simulator import pump_simulator_to_queue

_RECENT_MAX = 120


def _env_int(name: str, default: int) -> int:
    v = os.getenv(name)
    if not v:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if not v:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


BAUD = _env_int("MA200_BAUD", 1_000_000)
SIMULATE = _env_bool("MA200_SIMULATE", False)
SIM_INTERVAL_S = _env_int("MA200_SIM_INTERVAL_MS", 500) / 1000.0

app = FastAPI(title="MA200 Realtime", version="0.2.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

_client_queues: Dict[WebSocket, asyncio.Queue] = {}
_queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
_recent: deque = deque(maxlen=_RECENT_MAX)
_broadcaster = None
_sim_stop: asyncio.Event | None = None
_sim_task: asyncio.Task | None = None
_device_lock = asyncio.Lock()
_device_state: dict = {
    "connected": False,
    "port": None,
    "baud": BAUD,
    "simulate": SIMULATE,
    "error": None,
}


class ConnectRequest(BaseModel):
    port: str = Field(min_length=1)


@app.get("/")
async def index():
    return FileResponse(
        "static/index.html",
        headers={"Cache-Control": "no-cache"},
    )


@app.get("/api/ports")
async def api_ports():
    return {"ports": list_com_ports()}


@app.get("/api/device/status")
async def api_device_status():
    return dict(_device_state)


async def _broadcast(msg: dict) -> None:
    await _queue.put(msg)


async def _set_device_state(**updates) -> None:
    _device_state.update(updates)
    await _broadcast({"type": "device_status", **_device_state})


def _on_serial_status(connected: bool, error: Optional[str]) -> None:
    async def _apply() -> None:
        global _broadcaster
        async with _device_lock:
            if connected:
                await _set_device_state(connected=True, error=None)
                return
            port = _device_state.get("port")
            if _broadcaster is not None:
                _broadcaster.stop()
                _broadcaster = None
            await _set_device_state(
                connected=False,
                port=port,
                error=error or "Device disconnected",
            )

    asyncio.create_task(_apply())


async def _stop_device() -> None:
    global _broadcaster
    if _broadcaster is not None:
        _broadcaster.stop()
        _broadcaster = None


async def _start_device(port: str) -> None:
    global _broadcaster
    loop = asyncio.get_running_loop()
    _broadcaster = await pump_serial_to_queue(
        cfg=SerialConfig(port=port, baudrate=BAUD),
        queue=_queue,
        loop=loop,
        on_status=_on_serial_status,
    )


@app.post("/api/device/connect")
async def api_device_connect(body: ConnectRequest):
    if SIMULATE:
        raise HTTPException(
            status_code=400,
            detail="Demo mode is active. Restart without MA200_SIMULATE to use a real device.",
        )

    port = body.port.strip().upper()
    available = {p["port"].upper() for p in list_com_ports()}
    if port not in available:
        raise HTTPException(
            status_code=404,
            detail=f"{port} not found. Click Refresh and select the port shown for your MA200.",
        )

    async with _device_lock:
        await _stop_device()
        await _set_device_state(connected=False, port=port, error=None)
        try:
            await _start_device(port)
        except Exception as exc:
            await _set_device_state(connected=False, port=port, error=str(exc))
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"ok": True, "port": port, "baud": BAUD}


@app.post("/api/device/disconnect")
async def api_device_disconnect():
    async with _device_lock:
        port = _device_state.get("port")
        await _stop_device()
        await _set_device_state(connected=False, port=port, error=None)
    return {"ok": True}


@app.on_event("startup")
async def _startup() -> None:
    global _sim_stop, _sim_task
    asyncio.create_task(_fanout_task())
    if SIMULATE:
        _sim_stop = asyncio.Event()
        _sim_task = asyncio.create_task(
            pump_simulator_to_queue(
                queue=_queue,
                stop=_sim_stop,
                interval_s=SIM_INTERVAL_S,
            )
        )
        await _set_device_state(
            connected=True,
            port="simulator",
            simulate=True,
            error=None,
        )
    else:
        await _set_device_state(
            connected=False,
            port=None,
            simulate=False,
            error=None,
        )


@app.on_event("shutdown")
async def _shutdown() -> None:
    global _sim_stop, _sim_task
    if _sim_stop is not None:
        _sim_stop.set()
    if _sim_task is not None:
        _sim_task.cancel()
        try:
            await _sim_task
        except asyncio.CancelledError:
            pass
        _sim_task = None
        _sim_stop = None
    async with _device_lock:
        await _stop_device()


async def _fanout_task() -> None:
    while True:
        msg = await _queue.get()
        if msg.get("type") not in ("hello", "device_status"):
            _recent.append(msg)
        dead = []
        for ws, out_q in list(_client_queues.items()):
            try:
                out_q.put_nowait(msg)
            except asyncio.QueueFull:
                dead.append(ws)
        for ws in dead:
            _client_queues.pop(ws, None)


def _hello_payload() -> dict:
    if SIMULATE:
        return {
            "type": "hello",
            "port": "simulator",
            "baud": 0,
            "note": f"Demo data every {SIM_INTERVAL_S:.2f}s (MA200_SIMULATE=1)",
        }
    return {
        "type": "hello",
        "port": None,
        "baud": BAUD,
        "note": "Select a COM port and click Connect",
    }


async def _ws_sender(ws: WebSocket, out_q: asyncio.Queue) -> None:
    await ws.send_json(_hello_payload())
    await ws.send_json({"type": "device_status", **_device_state})
    for msg in list(_recent):
        await ws.send_json(msg)
    while True:
        msg = await out_q.get()
        await ws.send_json(msg)


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    out_q: asyncio.Queue = asyncio.Queue(maxsize=500)
    _client_queues[ws] = out_q
    sender = asyncio.create_task(_ws_sender(ws, out_q))
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        sender.cancel()
        try:
            await sender
        except asyncio.CancelledError:
            pass
        _client_queues.pop(ws, None)


def main() -> None:
    import webbrowser

    import uvicorn

    host = "127.0.0.1"
    port = 8000
    url = f"http://{host}:{port}/"
    webbrowser.open(url)
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()

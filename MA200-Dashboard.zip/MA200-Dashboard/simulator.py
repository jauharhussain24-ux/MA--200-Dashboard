from __future__ import annotations

import asyncio
import math
import random
from datetime import datetime, timezone

from serial_reader import make_payload

# Minimal MA200 full-format template (field 83 = IR BCc smoothed, µg/m³).
_TEMPLATE_FIELDS = [
    "MA200-SIM",
    "0",
    "10",
    "3",
    "1.13",
    "2026-01-01T00:00:00.00",
    "330",
    "0.0",
    "0.0",
    "0.0",
    "60",
    "64",
    "73",
    "0",
    "0",
    "0",
    "4",
    "100.00",
    "100.00",
    "72.00",
    "27.00",
    "32.00",
    "40.00",
    "16.00",
    "94240.00",
    "32.00",
    "DS-UV-B-G-R-IR",
] + ["0"] * 56 + ["0", "101146", "-127", "0000"]


def _make_sim_ma200_line(*, instrument_time: str, bc_ug_m3: float) -> str:
    fields = list(_TEMPLATE_FIELDS)
    fields[5] = instrument_time
    fields[83] = f"{bc_ug_m3:.2f}"
    return ",".join(fields)


async def pump_simulator_to_queue(
    *,
    queue: asyncio.Queue[dict],
    stop: asyncio.Event,
    interval_s: float = 0.5,
) -> None:
    """Push fake MA200 lines into the queue; stops when `stop` is set."""
    t = 0.0
    while not stop.is_set():
        bc_ug_m3 = 1.2 + 0.9 * math.sin(t / 10.0) + random.uniform(-0.08, 0.08)
        instrument_time = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.00")
        line = _make_sim_ma200_line(instrument_time=instrument_time, bc_ug_m3=bc_ug_m3)
        await queue.put(make_payload(line))
        t += 1.0
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval_s)
        except asyncio.TimeoutError:
            continue

from __future__ import annotations

import asyncio
import re
import threading
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Optional

import serial
from serial.tools import list_ports


@dataclass(frozen=True)
class SerialConfig:
    port: str = "COM15"
    baudrate: int = 1_000_000
    timeout_s: float = 1.0


# MA200 full serial streaming format (91 fields, DS-UV-B-G-R-IR marker at index 26).
_MA200_PREFIX = "MA200"
_MA200_INSTRUMENT_TIME_IDX = 5
_MA200_IR_BCC_SMOOTHED_IDX = 83
_MA200_MIN_FIELDS = _MA200_IR_BCC_SMOOTHED_IDX + 1
# Instrument reports IR BCc smoothed in µg/m³; dashboard displays ng/m³.
_UG_M3_TO_NG_M3 = 1_000.0

_NUM_RE = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")


def _to_float(text: str) -> Optional[float]:
    try:
        return float(text)
    except ValueError:
        return None


def _extract_first_float(line: str) -> Optional[float]:
    m = _NUM_RE.search(line)
    if not m:
        return None
    return _to_float(m.group(0))


def parse_ma200_line(line: str) -> Optional[dict]:
    """
    Parse a MA200 CSV streaming line and return IR BCc smoothed in ng/m³.

    Field 5: instrument timestamp (ISO 8601).
    Field 83: IR BCc smoothed (µg/m³ in the serial stream).
    """
    if not line.startswith(_MA200_PREFIX):
        return None

    parts = line.split(",")
    if len(parts) < _MA200_MIN_FIELDS:
        return None

    bc_ug_m3 = _to_float(parts[_MA200_IR_BCC_SMOOTHED_IDX])
    if bc_ug_m3 is None:
        return None

    instrument_time = parts[_MA200_INSTRUMENT_TIME_IDX].strip() or None
    bc_ng_m3 = bc_ug_m3 * _UG_M3_TO_NG_M3

    return {
        "instrument_time": instrument_time,
        "bc_ng_m3": bc_ng_m3,
        "bc_ug_m3": bc_ug_m3,
        "field": "IR BCc smoothed",
        "unit": "ng/m3",
    }


def list_com_ports() -> list[dict]:
    """Return available serial ports (COM on Windows)."""
    ports = []
    for info in list_ports.comports():
        ports.append(
            {
                "port": info.device,
                "description": info.description or "",
                "hwid": info.hwid or "",
            }
        )
    ports.sort(key=lambda p: p["port"])
    return ports


class SerialLineBroadcaster:
    """
    Reads bytes from a serial port on a background thread and hands decoded lines
    to an asyncio loop via a callback.
    """

    def __init__(self, cfg: SerialConfig) -> None:
        self._cfg = cfg
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(
        self,
        on_line: Callable[[str], None],
        *,
        on_status: Optional[Callable[[bool, Optional[str]], None]] = None,
    ) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run,
            args=(on_line, on_status),
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(
        self,
        on_line: Callable[[str], None],
        on_status: Optional[Callable[[bool, Optional[str]], None]],
    ) -> None:
        try:
            with serial.Serial(
                port=self._cfg.port,
                baudrate=self._cfg.baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=self._cfg.timeout_s,
            ) as ser:
                if on_status is not None:
                    on_status(True, None)
                while not self._stop.is_set():
                    raw = ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="replace").strip()
                    if line:
                        on_line(line)
        except Exception as exc:
            if on_status is not None and not self._stop.is_set():
                on_status(False, str(exc))


def make_payload(line: str) -> dict:
    ts = datetime.now().isoformat(timespec="milliseconds")
    parsed = parse_ma200_line(line)
    if parsed is not None:
        instrument_time = parsed["instrument_time"]
        return {
            "ts": instrument_time or ts,
            "instrument_time": instrument_time,
            "raw": line,
            "value": parsed["bc_ng_m3"],
            "unit": parsed["unit"],
            "field": parsed["field"],
        }

    value = _extract_first_float(line)
    return {"ts": ts, "raw": line, "value": value}


async def pump_serial_to_queue(
    *,
    cfg: SerialConfig,
    queue: "asyncio.Queue[dict]",
    loop: asyncio.AbstractEventLoop,
    on_status: Optional[Callable[[bool, Optional[str]], None]] = None,
) -> SerialLineBroadcaster:
    broadcaster = SerialLineBroadcaster(cfg)

    def on_line(line: str) -> None:
        payload = make_payload(line)
        loop.call_soon_threadsafe(queue.put_nowait, payload)

    def status_cb(connected: bool, error: Optional[str]) -> None:
        if on_status is not None:
            loop.call_soon_threadsafe(on_status, connected, error)

    broadcaster.start(on_line, on_status=status_cb)
    return broadcaster

# MA200 Realtime

Tiny local realtime interface for a Micro Aethalometer MA200 connected over USB.

Works on any Windows laptop — **no internet required**, **no COM port config in code**.

## Quick start

1. Copy this whole folder to the laptop (skip `.venv` if present).
2. Install [Python 3.11+](https://www.python.org/downloads/) and check **Add python.exe to PATH**.
3. Install packages once:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

4. Double-click **`MA200 Dashboard.bat`** — the server starts automatically and the dashboard opens in your browser.

Dashboard URL: `http://127.0.0.1:8000/` (also works as a bookmark once the server is running)

## Connect the MA200

1. Plug the MA200 into USB on the **same laptop** running the server.
2. Open the dashboard in Chrome, Edge, or Firefox.
3. Click **Refresh** — available COM ports appear in the dropdown.
4. Select the port for your instrument.
5. Click **Connect**.

When you unplug the MA200, the dashboard shows **Device disconnected**. To reconnect on the same or another laptop:

1. Plug the instrument back in.
2. Click **Refresh**.
3. Select the new COM port (it may differ on each laptop).
4. Click **Connect**.

No code changes or environment variables are needed when the COM port changes.

## Demo mode (no device)

For testing without an aethalometer:

```powershell
$env:MA200_SIMULATE = "1"
python app.py
```

Optional: `MA200_SIM_INTERVAL_MS=500` (milliseconds between fake readings).

## Files to share

Copy these to another laptop:

- `app.py`
- `serial_reader.py`
- `simulator.py`
- `static/` folder (includes offline Chart.js)
- `requirements.txt`
- `MA200 Dashboard.bat`
- `README.md`

Do **not** copy `.venv` — create a new virtual environment on the new machine.

## Serial settings

Default baud rate: **1,000,000**. Override if needed:

```powershell
$env:MA200_BAUD = "1000000"
python app.py
```

COM port is chosen in the dashboard — do not set `MA200_PORT`.

## Notes

- Everything runs locally; the chart and UI work without internet.
- Close the terminal window to stop the server.
- Edit code in any text editor — Cursor is optional.
